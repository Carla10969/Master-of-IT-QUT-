USE world;
CREATE TABLE AccountUser (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
);

USE world;
SELECT id, username, password, create_time FROM AccountUser;

USE world;
CREATE TABLE Note (
	user_id INT NOT NULL PRIMARY KEY,
    content VARCHAR(2000) NOT NULL,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
);