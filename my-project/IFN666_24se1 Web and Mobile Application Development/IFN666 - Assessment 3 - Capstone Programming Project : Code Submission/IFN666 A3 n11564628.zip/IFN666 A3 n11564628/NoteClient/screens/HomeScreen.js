import React, { useState, useEffect } from "react";
import { Text, TouchableOpacity, StyleSheet, View, Image } from "react-native";
import { GlobalLayout } from "../components/Layout";
import { GlobalStyles } from "../styles/global"; // Make sure this path is correct in your project

export default function WeatherScreen() {
  const [weather, setWeather] = useState(null);
  const [city, setCity] = useState("Brisbane");
  const [imageIndex, setImageIndex] = useState(0);
  const globalStyles = GlobalStyles();

  const images = [
    require('../assets/barB.png'),
    require('../assets/IMG_2140.png'),
    require('../assets/IMG_2166.png'),
    require('../assets/IMG_2163.png'),
    require('../assets/IMG_2162.png'),
    require('../assets/IMG_2161.png'),
    require('../assets/IMG_2160.png'), 
  ];

  const fetchWeather = async (city) => {
    const API_KEY = '0d998c0f01c11cd3014f15f5f022313b';
    const weatherURL = `http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}`;

    try {
      const response = await fetch(weatherURL);
      const data = await response.json();
      
      if (response.ok) {
        setWeather(data);
        const randomIndex = Math.floor(Math.random() * images.length);
        setImageIndex(randomIndex);
      } else {
        console.error('Error:', data.message);
      }
    } catch (error) {
      console.error('Error fetching weather data:', error);
    }
  };

  useEffect(() => {   
    fetchWeather(city);
  }, [city]);

  return (
    <GlobalLayout style={styles.globalLayout}>
      {weather ? (
        <View style={styles.content}>
          <Image source={images[imageIndex]} style={styles.logo} />
          <View style={styles.weatherInfo}>
            <Text style={styles.weatherText}> {weather.name}</Text>
            <Text style={styles.weatherText}> {(weather.main.temp - 273.15).toFixed(2)}°C</Text>
            <Text style={styles.weatherText}> {weather.weather[0].description}</Text>
          </View>
        </View>
      ) : (
        <Text style={styles.weatherText}>Loading weather data...</Text>
      )}
      <TouchableOpacity
        onPress={() => fetchWeather(city)}
        style={styles.touchable}
      >                   
        <Text style={styles.buttonText}>*ੈ✩‧₊˚ℳ𝒶𝑔𝒾𝒸₊✩‧₊˚౨ৎ˚₊✩‧₊</Text>
      </TouchableOpacity>
    </GlobalLayout>
  );
}

const styles = StyleSheet.create({
  globalLayout: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8c8dc', 
  },
  content: {
    alignItems: 'center',
    marginBottom: 20,
  },
  logo: {
    width: 250,
    height: 250,
    borderRadius: 125, 
    overflow: 'hidden', 
  },
  touchable: {
    height: 60,
    marginTop: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'hotpink',
    paddingHorizontal: 20,
    borderRadius: 35,
    elevation: 3, // Shadow for Android
    shadowColor: '#000', // Shadow for iOS
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 2,
  },
  buttonText: {
    color: 'white',
    fontSize: 23,
  },
  weatherInfo: {
    marginTop: 20,
    alignItems: 'center',
    backgroundColor: '#ffc1cc', // Light pink with some transparency
    padding: 50,
    borderRadius: 10,
    shadowColor: '#000',
    borderRadius: 20,
  },
  weatherText: {
    color: 'white', // Contrasting text color for readability
    fontSize: 26,
    lineHeight: 40,
  },
});
