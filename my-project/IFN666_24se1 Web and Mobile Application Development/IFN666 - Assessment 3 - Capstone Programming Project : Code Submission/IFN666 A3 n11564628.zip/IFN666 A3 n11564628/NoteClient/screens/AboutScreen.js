// AboutScreen.js
import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';

const AboutScreen = () => {
    return (
      <ScrollView style={styles.container}>
        <Image source={require('../assets/note.png')} style={styles.image} />
        <View style={styles.content}>
          <Text style={styles.header}>𝓐𝓫𝓸𝓾𝓽</Text>
          <Text style={styles.text1}>
          " 𝑺𝒊𝒎𝒑𝒍𝒆 𝒊𝒔 𝒕𝒉𝒆 𝑩𝑬𝑺𝑻 "   
          </Text>
          <Text style={styles.text1}>
          <Text style={styles.text2}>
          ❀｡*。𝒷𝓎 𝒞𝓁𝒶𝓇𝒶
          </Text>
          <Text style={styles.text2}/> 
          </Text>
        </View>
      </ScrollView>
    );
  };
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fdeef9', 
    },
    image: {
      width: '100%',
      height: 400, // Adjust the height as needed
      resizeMode: 'cover',
      marginBottom: 15, // Ensures the image covers the designated space without stretching
    },
    content: {
      padding: 20,
    },
    header: {
      fontSize: 24,
      fontWeight: 'bold',
      marginBottom: 70,
      color: '#d6336c', // A modern, deeper pink for headings
      textAlign: 'center', // Center-align the text
    },
    text1: {
      fontSize: 20,
      lineHeight: 24, // Adequate line spacing for readability
      color: 'darkgray', // A darker color for the text for contrast
      textAlign: 'center',
      marginBottom: 40,
    },
    text2: {
      fontSize: 12,
      lineHeight: 24, 
      color: '#353535', 
      textAlign: 'center',
      color: 'gray',
    },
  });
  
  export default AboutScreen;