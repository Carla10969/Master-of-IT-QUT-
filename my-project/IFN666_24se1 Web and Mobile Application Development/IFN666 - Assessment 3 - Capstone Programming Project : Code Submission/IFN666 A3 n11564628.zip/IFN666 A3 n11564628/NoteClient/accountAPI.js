import API from './api';

export const createUser = async (username, password, confirmPassword) => {
  try {
    console.error('ready to create user:', username, password, confirmPassword);
    const response = await API.post('/account/create', { username, password, confirmPassword });
    console.log("response: ", response);
    //return response.data;

  } catch (error) {
    console.error('Error creating user:', error);
    throw error;
  }
};
