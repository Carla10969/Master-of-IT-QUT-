export const formatAttractionURL = (attraction) =>   //generate a URL for the Wikipedia page of each attraction.
  `https://en.wikipedia.org/wiki/${attraction.replace(/\s/g, "_")}`;