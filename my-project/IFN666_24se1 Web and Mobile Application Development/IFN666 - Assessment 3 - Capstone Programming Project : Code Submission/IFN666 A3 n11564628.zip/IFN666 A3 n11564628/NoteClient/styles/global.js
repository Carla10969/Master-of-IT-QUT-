import { StyleSheet } from "react-native";
import { useTheme } from "../context/theme";

export function GlobalStyles() {
  const { isLargeText } = useTheme();

  const styles = StyleSheet.create({   //styles object contains a text style that sets the font size to 28 if isLargeText is true, and 16 if isLargeText is false.
    text: {
      fontSize: isLargeText ? 28 : 16,
    },
  });

  return styles;
}