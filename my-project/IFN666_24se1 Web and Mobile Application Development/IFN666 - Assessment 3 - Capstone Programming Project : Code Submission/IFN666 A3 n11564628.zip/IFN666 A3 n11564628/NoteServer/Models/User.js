const { DataTypes, Model } = require('sequelize');
const sequelize = require('../db');

class AccountUser extends Model {}

AccountUser.init({
  username: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  },
}, {
  // Other model options go here
  sequelize, // We need to pass the connection instance
  modelName: 'AccountUser', // We need to choose the model name
  tableName: 'AccountUser', // Specify the table name
  timestamps: false
});

module.exports = AccountUser;