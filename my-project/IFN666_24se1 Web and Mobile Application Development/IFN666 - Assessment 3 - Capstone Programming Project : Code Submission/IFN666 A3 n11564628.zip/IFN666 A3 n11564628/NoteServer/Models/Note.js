const { DataTypes, Model } = require('sequelize');
const sequelize = require('../db');

class Note extends Model {}

Note.init({
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true
  },
  content: {
    type: DataTypes.STRING,
    allowNull: false
  }
}, {
  sequelize,
  modelName: 'Note',
  tableName: 'Note',
  timestamps: false
});

module.exports = Note;