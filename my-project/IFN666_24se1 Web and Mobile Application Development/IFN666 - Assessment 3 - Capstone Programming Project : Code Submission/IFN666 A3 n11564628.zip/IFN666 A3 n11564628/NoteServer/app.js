// import
const express = require('express');
const sequelize = require('./db');
const cors = require('cors');

// controllers
const accountController = require('./Controller/accountController');
const noteController = require('./Controller/noteController');

// create an express app
const app = express();
// This line is important
app.use(express.json());
app.use(cors({
  origin: 'exp://172.20.10.5:8081'  // Adjust this to match your client's actual origin
}));
// validate the connection
sequelize.authenticate()
  .then(() => {
    console.log('Connection has been established successfully.');
  })
  .catch(err => {
    console.error('Unable to connect to the database:', err);
});

app.use('/account', accountController);  // use account controller
app.use('/note', noteController);  // use note controller

// create a route
app.get('/', (req, res) => {
  res.send('Hello World!');
});

// start the server
app.listen(3000, () => {
  console.log('App is listening on port 3000');
});