export const formatAttractionURL = (attraction) =>   
  `https://en.wikipedia.org/wiki/${attraction.replace(/\s/g, "_")}`;