import React, { useState } from 'react';
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { FontAwesome5 } from "@expo/vector-icons";
import { FontSizeProvider } from './components/FontSizeContext';


import HomeScreen from "./screens/HomeScreen";
import SettingsScreen from "./screens/SettingsScreen";
import AboutScreen from "./screens/AboutScreen";
import LoginScreen from "./screens/LoginScreen";
import NoteScreen from "./screens/NoteScreen";
import SplashScreen from "./components/SplashScreen";
import RegisterScreen from "./screens/RegisterScreen";
import DocumentScreen from "./screens/DocumentScreen";


import { ThemeProvider } from "./context/theme";
import { SettingsProvider } from './context/SettingsContext';

const Tab = createBottomTabNavigator();  

export default function App() {
  const [isAppReady, setAppReady] = useState(false);
  

  if (!isAppReady) {
    return <SplashScreen onFinish={() => setAppReady(true)} />;
  }

  return (
    <SettingsProvider>
      <FontSizeProvider>  
        <ThemeProvider>  
            <NavigationContainer>
             <Tab.Navigator
               initialRouteName="About"
               screenOptions={({ route }) => ({
                tabBarIcon: ({ color, size }) => {
                  let iconName;
                  if (route.name === "Home") {
                    iconName = "home";
                  } else if (route.name === "Note") {
                    iconName = "sticky-note";
                  } else if (route.name === "Login") {
                    iconName = "sign-in-alt";
                  } else if (route.name === "Settings") {
                    iconName = "cog";
                  } else if (route.name === "About") {
                    iconName = "info-circle";
                  }
                  return <FontAwesome5 name={iconName} size={size} color={color} />;
                },
              })}
            >
              <Tab.Screen name="Home" component={HomeScreen} />
              <Tab.Screen name="Register" component={RegisterScreen} options={{ tabBarButton: () => null }}/>
              <Tab.Screen name="Note" component={NoteScreen} />
              <Tab.Screen name="Login" component={LoginScreen} />
              <Tab.Screen name="About" component={AboutScreen} />
              <Tab.Screen name="Settings" component={SettingsScreen} />
              <Tab.Screen name="Document" component={DocumentScreen} options={{ tabBarButton: () => null }}/>
            </Tab.Navigator>
          </NavigationContainer>
        </ThemeProvider>
      </FontSizeProvider>
    </SettingsProvider>
  );
}
