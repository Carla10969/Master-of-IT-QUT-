import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import AppLoading from 'expo-splash-screen';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function SplashScreen({ onFinish }) {
  const [isLoadingComplete, setLoadingComplete] = useState(false);

  useEffect(() => {
    const loadResources = async () => {
      try {
        const data = await AsyncStorage.getItem('someDataKey');
        await new Promise(resolve => setTimeout(resolve, 3000));
      } catch (e) {
        console.warn(e);
      } finally {
        setLoadingComplete(true);
        onFinish();
      }
    };

    loadResources();
  }, []);

  return (
    <View style={styles.container}>
      <Image source={require('../assets/girl.png')} style={styles.image} />
      <Text style={styles.text}>～Welcome to Carla Note～</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#D7ACB7',
  
  },
  text: {
    fontSize: 20,
    color: 'white',
  },
   image: {
     width: 200,
     height: 200,
     marginBottom: 20,
  },
  

});


