import React, { createContext, useState, useContext } from 'react';


const SettingsContext = createContext();


export const SettingsProvider = ({ children }) => {
  const [theme, setTheme] = useState('light'); 
  const [language, setLanguage] = useState('en'); 
  const [fontSize, setFontSize] = useState(14); 

  const toggleTheme = () => {
    setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  const changeLanguage = (lang) => {
    setLanguage(lang);
  };

  const adjustFontSize = (size) => {
    setFontSize(size);
  };

  return (
    <SettingsContext.Provider value={{ theme, language, fontSize, toggleTheme, changeLanguage, adjustFontSize }}>
      {children}
    </SettingsContext.Provider>
  );
};


export const useSettings = () => useContext(SettingsContext);
