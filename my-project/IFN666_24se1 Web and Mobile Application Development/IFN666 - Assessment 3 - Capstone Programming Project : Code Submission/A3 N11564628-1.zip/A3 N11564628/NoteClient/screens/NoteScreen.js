import React, { useState } from 'react';
import { View, TextInput, Text, FlatList, StyleSheet, Image, Keyboard } from 'react-native';

const NoteScreen = () => {
  const [note, setNote] = useState('');
  const [notes, setNotes] = useState([]);

  const handleSaveNote = () => {
    console.log("Submitting and trying to dismiss the keyboard");
    if (note.trim()) {
      const newNote = {
        text: note,
        timestamp: new Date().toLocaleString()  
      };
      
      setNotes(prevNotes => [newNote, ...prevNotes]);
      setNote('');
      Keyboard.dismiss();
    }
  };

  return (
    <View style={styles.container}>
      <Image source={require('../assets/note2.png')} style={styles.logo} />
      <Text style={styles.headerText}>ᴛᴀᴋᴇ ᴀ ɴᴏᴛᴇ</Text>
      <TextInput
          style={styles.input}
          placeholder="What's on your mind..."
          placeholderTextColor="#888"
          value={note}
          onChangeText={setNote}
          multiline
          returnKeyType="done"
          onSubmitEditing={handleSaveNote}
          blurOnSubmit={true}
      />

      <FlatList
        data={notes}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.note}>
            <Text style={styles.noteText}>{item.text}</Text>
            <Text style={styles.timestamp}>{item.timestamp}</Text>
          </View>
        )}
        style={styles.notesList}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    paddingTop: 50,
  },
  logo: {
    width: 250,
    height: 250,
    marginBottom: 20,
  },
  headerText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    minHeight: 50,
    borderColor: '#ccc',
    borderWidth: 1,
    borderTopWidth: 0,
    padding: 10,
    fontSize: 16,
    backgroundColor: '#fff',
    shadowColor: '#000', 
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 2,
    marginBottom: 13,
  },
  notesList: {
    width: '80%',
  },
  note: {
    width: '100%',
    backgroundColor: '#ecc5d0',
    padding: 18,
    marginTop: 20,
    borderTopLeftRadius: 20, 
    borderTopRightRadius: 40, 
    borderBottomLeftRadius: 50, 
    borderBottomRightRadius: 40,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  noteText: {
    fontSize: 16,
    color: '#000',
    paddingLeft: 10,
  },
  timestamp: {
    fontSize: 12,
    color: '#666',
  },
});

export default NoteScreen;


