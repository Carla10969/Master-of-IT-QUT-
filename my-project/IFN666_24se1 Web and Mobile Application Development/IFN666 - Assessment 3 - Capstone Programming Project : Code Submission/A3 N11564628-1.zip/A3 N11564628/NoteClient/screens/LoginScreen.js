import React, { useState } from 'react';
import { View, Text, Image, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';


const LoginScreen = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigation = useNavigation();

    const handleLoginWithEmail = () => {
    console.log('Logging in with Email:', { email, password });
    navigation.navigate('Home');
  };

  return (
    <View style={styles.container}>
        <View style={styles.header}>
            <Image source={require('../assets/IMG_2160.png')} style={styles.logo} />
            <Text style={styles.greeting}>ʟᴏɢ ɪɴ ᴏɴ ᴄᴀʀʟᴀ ɴᴏᴛᴇ</Text>
        </View>
        <TextInput
            style={styles.input}
            placeholder="clara@gmail.com"
            keyboardType="email-address"
            value={email}
            onChangeText={setEmail}
        />
        <TextInput
            style={styles.input}
            placeholder="*******"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
        />
        <TouchableOpacity style={styles.button} onPress={handleLoginWithEmail}>
            <Text style={styles.buttonText}>LOGIN WITH EMAIL</Text>
        </TouchableOpacity>
        <Text style={styles.signUpText}>
            Didn't have an account? <Text style={styles.signUpLink} onPress={() => navigation.navigate('Register')}>Sign Up</Text>
        </Text>
        <Text style={styles.termsText}>
            <Text style={styles.termsLink} onPress={() => navigation.navigate('Document')}>Terms & Privacy Policy</Text>
        </Text>
    </View>
  );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        padding: 20,
        backgroundColor: '#fff',
    },
    header: {
        alignItems: 'center',
        marginBottom: 20,
    },
    logo: {
        width: 250,
        height: 250,
        marginBottom: 20,
    },
    greeting: {
        fontSize: 20,
        fontWeight: 'bold',
    },
    input: {
        width: '100%',
        height: 50,
        padding: 10,
        marginVertical: 8,
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 10,
        shadowColor: '#777', 
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 1,
    },
    button: {
        width: '100%',
        height: 50,
        backgroundColor: '#e18e96',
        alignItems: 'center',
        justifyContent: 'center',
        marginVertical: 8,
        borderRadius: 10,
        shadowColor: '#000', // Shadow 
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 2,
    },
    buttonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: 'bold',
    },
    signUpText: {
        marginTop: 20,
        fontSize: 16,
        color: '#7d7576',
    },
    signUpLink: {
        color: '#d998a0',
        fontWeight: 'bold',
    },
    termsText: {
        marginTop: 20,
        fontSize: 14,
        textAlign: 'center',
        color: '#7d7576',
        
    },
    termsLink: {
        fontWeight: 'bold',
    },
});

export default LoginScreen;
