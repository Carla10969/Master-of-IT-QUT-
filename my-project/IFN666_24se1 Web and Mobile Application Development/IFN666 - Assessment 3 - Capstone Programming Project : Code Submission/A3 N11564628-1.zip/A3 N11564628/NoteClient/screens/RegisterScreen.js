import React, { useState } from 'react';
import { View, Text, Image, TextInput, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';

export default function SignupScreen() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSignup = async () => {
    try {
      console.log('ready to sign up:', username, password, confirmPassword);
      
      const user = await createUser(username, password, confirmPassword);
      console.log('User created:', user);
      
    } catch (error) {
      console.log('Signup error:', error);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Image source={require('../assets/IMG_2162.png')} style={styles.topImage} />
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="＊𝕌𝕤𝕖𝕣𝕟𝕒𝕞𝕖＊"
          onChangeText={setUsername}
          value={username}
        />
        <TextInput
          style={styles.input}
          placeholder="𓏲 ℙ𝕒𝕤𝕤𝕨𝕠𝕣𝕕 𓂀"
          secureTextEntry
          onChangeText={setPassword}
          value={password}
        />
        <TextInput
          style={styles.input}
          placeholder="𓂡 ℂ𝕠𝕟𝕗𝕚𝕣𝕞 ℙ𝕒𝕤𝕤𝕨𝕠𝕣𝕕 𓅎"
          secureTextEntry
          onChangeText={setConfirmPassword}
          value={confirmPassword}
        />
      </View>
      <TouchableOpacity style={styles.signupButton} onPress={handleSignup}>
        <Text style={styles.buttonText}>⟣  𝐉 𝐎 𝐈 𝐍  ⟢</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#c9e8e1',
  },
  topImage: {
    width: '100%',
    height: 350, 
    resizeMode: 'cover'
  },
  inputContainer: {
    width: '80%',
    height: 300,
    marginBottom: 10,
    padding: 20,
  },
  input: {
    backgroundColor: '#fefdfa',
    padding: 20,
    borderRadius: 10,
    marginBottom: 10,
    fontSize: 16,
    shadowColor: '#000', 
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  signupButton: {
    backgroundColor: '#f2bdcd', 
    padding: 10,
    borderRadius: 25,
    width: '70%',
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: -70,
    shadowColor: '#000', 
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 2,
  },
  buttonText: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'center',
  }
});
