import React from 'react';
import { View, Text, Button, StyleSheet, Image, ScrollView } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useSettings } from '../context/SettingsContext';

const SettingsScreen = () => {
  const { theme, language, fontSize, toggleTheme, changeLanguage, adjustFontSize } = useSettings();

 
  const dynamicStyles = styles(theme);

  return (
    <ScrollView style={dynamicStyles.container}>
      <Image 
        source={require('../assets/IMG_2162.png')} 
        style={dynamicStyles.image}
      />

      <View style={dynamicStyles.settingsContainer}>
        <Text style={dynamicStyles.sectionTitle}>Appearance</Text>
        <Button title={`Switch to ${theme === 'light' ? 'Dark' : 'Light'} Theme`} onPress={toggleTheme} color={dynamicStyles.button.color} />

        <Text style={dynamicStyles.sectionTitle}>Language</Text>
        <Picker
          selectedValue={language}
          style={dynamicStyles.picker}
          onValueChange={(itemValue) => changeLanguage(itemValue)}
          itemStyle={dynamicStyles.pickerItem}
        >
          <Picker.Item label="English" value="en" />
          <Picker.Item label="Spanish" value="es" />
          <Picker.Item label="French" value="fr" />
          <Picker.Item label="日本語" value="jp" />
          <Picker.Item label="中文" value="cn" />
        </Picker>

        <Text style={dynamicStyles.sectionTitle}>Text Size</Text>
        <View style={dynamicStyles.buttonGroup}>
          <Button title="Increase Font Size" onPress={() => adjustFontSize(fontSize + 1)} color="darkgray" />
          <Button title="Decrease Font Size" onPress={() => adjustFontSize(fontSize - 1)} color="skyblue" />
        </View>
      </View>
    </ScrollView>
  );
};


const styles = (theme) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme === 'light' ? '#FFF0F5' : '#D87093', 
  },
  image: {
    width: '100%',
    height: 300,
    resizeMode: 'cover'
  },
  settingsContainer: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
    color: theme === 'light' ? 'darkgray' : '#FFF0F5', 
  },
  picker: {
    width: '100%',
    height: 60,
    marginBottom: 20,
  },
  pickerItem: {
    height: 80,
    color: theme === 'light' ? 'darkgray' : '#FFF0F5',  
  },
  buttonGroup: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button: {
    color: theme === 'light' ? '#FF69B4' : '#FFB6C1', 
  }
});

export default SettingsScreen;
