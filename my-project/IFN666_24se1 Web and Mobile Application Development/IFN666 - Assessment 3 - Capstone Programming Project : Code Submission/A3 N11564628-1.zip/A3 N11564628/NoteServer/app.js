const express = require('express');
const sequelize = require('./db');
const cors = require('cors');

const accountController = require('./Controller/accountController');
const noteController = require('./Controller/noteController');


const app = express();

app.use(express.json());
app.use(cors({
  origin: 'exp://172.20.10.5:8081'  
}));

sequelize.authenticate()
  .then(() => {
    console.log('Connection has been established successfully.');
  })
  .catch(err => {
    console.error('Unable to connect to the database:', err);
});

app.use('/account', accountController);  
app.use('/note', noteController);  


app.get('/', (req, res) => {
  res.send('Hello World!');
});


app.listen(3000, () => {
  console.log('App is listening on port 3000');
});