const express = require('express');
const router = express.Router();
const AccountUser = require('../Models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
require('dotenv').config();

// test login
router.get('/fetch', async (req, res) => {
    fetch('http://localhost:3000/account', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: 'amber',
          password: '123',
        }),
      })
      .then(response => response.json())
      .then(data => {
        console.log(data);
        res.json({ message: 'fetch in successfully'});
      })
      .catch((error) => {
        console.error('Error:', error);
      });
});

// test token validation
router.get('/fetchNote', async (req, res) => {
    const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NywiaWF0IjoxNzE2NzIyMzkxLCJleHAiOjE3MTY3MjI1MTF9.JoKSI0OJWwZxAP4O34pJtf2d9A8YDdKAZS3tj4JEL0w";
    fetch('http://localhost:3000/note/6', {
        method: 'GET',
        headers: {
          'Authorization': 'Bearer ' + token,
          'Content-Type': 'application/json',
        },
      })
      .then(response => response.json())
      .then(data => {
        res.json({ message: 'fetchNote in successfully'});
        console.log(data);
      })
      .catch((error) => {
        console.error('Error:', error);
      });
    }
);

router.get('/', async (req, res) => {
    const users = await AccountUser.findAll();
    if (!users) {
        return res.status(404).json({ message: 'No users found' });
    }
    
    res.json(users);
});


router.post('/', async (req, res) => {
    const { username, password } = req.body;

    
    const user = await AccountUser.findOne({ where: { username } });
    if (!user) {
        return res.status(400).json({ message: 'Invalid username or password' });
    }
    
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
        return res.status(400).json({ message: 'Invalid username or password' });
    }

    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '7d' });

    res.json({ message: 'Logged in successfully', token }); 
});

// Create a account
router.post('/create', async (req, res) => {
  console.log('creat: ', req); 
  const { username, password, confirmPassword } = req.body;
  console.log('creat2: ', username, password, confirmPassword);
        if (!username || !password || !confirmPassword) {
            return res.status(400).json({ errorCode: 400, message: 'All fields are required' });
        }
    
        if (password !== confirmPassword) {
            return res.status(400).json({ errorCode: 400, message: 'Passwords do not match' });
        }
    
        const user = await AccountUser.findOne({ where: { username } });
        if (user) {
            return res.status(400).json({ errorCode: 400, message: 'Username already exists' });
        }
    
        bcrypt.hash(password, process.env.SALT_ROUNDS, async (err, hash) => {
            if (err) {
                return res.status(500).json({ errorCode: 500, message: 'Error hashing password' });
            }
            let date = new Date();
            let sqlDate = date.toISOString().slice(0, 19).replace('T', ' ');

            const newUser = await AccountUser.create({   
                username, 
                password: hash, 
            });

            res.status(201).json({ message: 'Account created successfully', user: newUser });
        });
});

module.exports = router;