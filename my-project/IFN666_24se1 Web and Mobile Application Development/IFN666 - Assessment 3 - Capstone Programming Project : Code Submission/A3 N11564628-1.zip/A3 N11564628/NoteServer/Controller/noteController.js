const express = require('express');
const router = express.Router();
const authenticateToken = require('../Middleware/authenticateToken');
const Note = require('../Models/Note');

router.get('/:user_id', authenticateToken, async (req, res) => {
    const { user_id } = req.params;

    const note = await Note.findOne({ where: { user_id } });
    if (!note) {
        return res.status(400).json({ message: "Note not found!" });
    }

    res.json({ message: 'Find the Note successfully', note: note });
});

// create new note
router.post('/', authenticateToken, async (req, res) => {
    const { user_id, content } = req.body;

    const note = await Note.findOne({ where: { user_id } });

    if (!note) {
        // Create new note
        const newNote = await Note.create({ 
            user_id, 
            content
        });
        res.json({ message: 'Note created successfully', note: newNote });
    }
});

//update old note
router.put('/', authenticateToken, async (req, res) => {
    const { user_id, content } = req.body;

    const [updated] = await Note.update({ content }, { where: { user_id } });

    if (!updated) {
        return res.status(400).json({ message: 'Unable to update the note' });
    }

    const updatedNote = await Note.findOne({ where: { user_id } });
    res.json({ message: 'Note updated successfully', note: updatedNote });
    
});

// delete note
router.delete('/', authenticateToken, async (req, res) => {
    const { user_id } = req.body;

    // Delete note
    const deleted = await Note.destroy({ where: { user_id } });

    if (!deleted) {
        return res.status(400).json({ message: 'Unable to delete the note' });
    }

    res.json({ message: 'Note deleted successfully' });
});

module.exports = router;