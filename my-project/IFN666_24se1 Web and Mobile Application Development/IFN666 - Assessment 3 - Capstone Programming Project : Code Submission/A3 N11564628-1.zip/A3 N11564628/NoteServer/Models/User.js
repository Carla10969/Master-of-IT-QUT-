const { DataTypes, Model } = require('sequelize');
const sequelize = require('../db');

class AccountUser extends Model {}

AccountUser.init({
  username: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  },
}, {
  
  sequelize, 
  modelName: 'AccountUser', 
  tableName: 'AccountUser', 
  timestamps: false
});

module.exports = AccountUser;