import socket
import time
from datetime import datetime
import threading

# initial setting
print("Enter Server IP Address: ")
SERVER_IP = input()
print("Enter Server Port Number")
SERVER_PORT = input()
SERVER_PORT=int(SERVER_PORT)


REQUEST_INTERVAL = 3
running = True

def get_timestamp():
    return datetime.now().strftime("%H:%M:%S.%f")[:-3]

def handle_input():
    global running
    while running:
        cmd = input().strip()
        if cmd.lower() == 'e':  # Termination command
            send_termination_signal()
            receive_ack_termination_signal()
            send_ack_termination_confirmation_signal()
            running = False
def send_termination_signal():
    termination_timestamp = get_timestamp()
    termination_message = f"E {seqno:05d} {termination_timestamp}"
    server_socket.sendto(termination_message.encode(), client_address)
    print(f"Sent termination message to client: {termination_message}")
def receive_ack_termination_signal():
    ack_termination_message, client_address = server_socket.recvfrom(1024)
    decode_ack_termination_massage = ack_termination_message.decode()
    print(f"Received ACK from client: {decode_ack_termination_massage}")
def send_ack_termination_confirmation_signal():
    ack_termination_confirmation_timestamp = get_timestamp()
    ack_termination_confirm_message = f"ACK E {seqno:05d} {ack_termination_confirmation_timestamp}"
    server_socket.sendto(ack_termination_confirm_message.encode(), client_address)
    print(f"Sent termination message to client: {ack_termination_confirm_message}")
# create UDP
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# bind ip /port
server_socket.bind((SERVER_IP, SERVER_PORT))

#listening
print("Server is listening...")

#keyboad access
input_thread = threading.Thread(target=handle_input)
input_thread.start()

#basic connection success message 
data, client_address = server_socket.recvfrom(1024)
print (f'Message from client: {data.decode()}')
message= ("Hello I am UDP Server").encode()
server_socket.sendto(message, client_address)

seqno = 1
while running:
    
    #send request 
    starttime= time.perf_counter()
    request_timestamp = get_timestamp()  # Format the timestamp
    request_message = f"R {seqno:05d} {request_timestamp}"
    server_socket.sendto(request_message.encode(),client_address)
    print(f"Sent request to client: {request_message}")

    # Receive ACK message from the client
    ack_message, client_address = server_socket.recvfrom(1024)
    decode_ack_massage = ack_message.decode()
   

    if decode_ack_massage.startswith('E'):  # Termination message from client
        print(f"Received termination request from client: {decode_ack_massage}")

        ack_termination_serer_timestamp = get_timestamp()
        ack_termination_serer = f"ACK E {seqno:05d} {ack_termination_serer_timestamp}"
        server_socket.sendto(ack_termination_serer.encode(), client_address)
        print(f"Sent ACK for termination to client: {ack_termination_serer}")

        ack_termination_confirm_message_client, server_address = server_socket.recvfrom(1024)
        decode_ack_termination_confirm_message_cliente = ack_termination_confirm_message_client.decode()
        print(f"Receive ACK termination confirmed from server: {decode_ack_termination_confirm_message_cliente}")

        running = False
        break
    
    print(f"Received ACK from client: {decode_ack_massage}")

    # Generate timestamp for ACK confirm message
    timestamp_receive = get_timestamp()
    ack_confirm_message = f"ACK R {seqno:05d} {timestamp_receive}"

    #Send ACK Confirm meesgae to client 
    
    server_socket.sendto(ack_confirm_message.encode(), client_address)
    print(f"Sent ACK confirmation to client: {ack_confirm_message}")
    
    finishTime =  time.perf_counter()

    rtt = finishTime-starttime
    print(f"Round Trip Time (RTT): {rtt:.3f} seconds")
    # Increment sequence number
    seqno += 1
    
    # Wait for 3 seconds before sending the next request
    time.sleep(REQUEST_INTERVAL)

# # Termination sequence
# termination_timestamp = get_timestamp()
# termination_message = f"E {seqno:05d} {termination_timestamp}"
# server_socket.sendto(termination_message.encode(), client_address)
# print(f"Sent termination message to client: {termination_message}")

# # Receive ACK for termination
# ack_termination, client_address = server_socket.recvfrom(1024)
# print(f"Received termination ACK from client: {ack_termination.decode()}")

# # Send final ACK
# final_ack = f"ACK E {seqno:05d} {get_timestamp()}"
# server_socket.sendto(final_ack.encode(), client_address)
# print(f"Sent final ACK to client: {final_ack}")

server_socket.close()

print("Server shutdown.")   
   
    

