import socket
import time
from datetime import datetime
import threading
import sys
from threading import Lock
# initial setting
print("Enter Server IP Address: ")
SERVER_IP = input()
print("Enter Server Port Number")
SERVER_PORT = input()
SERVER_PORT=int(SERVER_PORT)

running = True
socket_lock = Lock()
def get_timestamp():
    return datetime.now().strftime("%H:%M:%S.%f")[:-3]

def handle_input():
    global running    
    while running:
        cmd = input()
        if cmd.lower() == 'e':  
            send_termination_signal()
            # receive_ack_termination_signal()
            # send_ack_termination_confirmation_signal()
            running = False

def send_termination_signal():
    termination_cleint_side_timestamp = get_timestamp()
    termination_message_cleint_side = f"E {seqno:05d} {termination_cleint_side_timestamp}"
    client_socket.sendto(termination_message_cleint_side.encode(), server_address)
    print(f"Sent termination message to server: {termination_message_cleint_side}")

# def receive_ack_termination_signal():
#     ack_termination_message_server, server_address = client_socket.recvfrom(1024)
#     decode_ack_termination_massage_server = ack_termination_message_server.decode()
#     print(f"Received ACK termination from server: {decode_ack_termination_massage_server}")

# def send_ack_termination_confirmation_signal():
#     ack_termination_confirmation_timestamp_client = get_timestamp()
#     ack_termination_confirm_message_cleint = f"ACK E {seqno:05d} {ack_termination_confirmation_timestamp_client}"
#     client_socket.sendto(ack_termination_confirm_message_cleint.encode(), server_address)
#     print(f"Sent termination message to server: {ack_termination_confirm_message_cleint}")
    
# create UDP
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

client_socket.connect((SERVER_IP,SERVER_PORT))
#keyboad access

input_thread = threading.Thread(target=handle_input)
input_thread.start()

#basic connection success message 
message = 'Hello UDP Server!'
client_socket.sendto(message.encode(), (SERVER_IP, SERVER_PORT))
response, server_address = client_socket.recvfrom(1024)
print(f"Response from server: {response.decode()}")

seqno = 1
while running:
    
    #receive request from server
    request_message, (SERVER_IP, SERVER_PORT) = client_socket.recvfrom(1024)
    decode_message=request_message.decode()

    # Termination message from server
    if decode_message.startswith('E'):  
        print(f"Received termination request from client: {decode_message}")
        ack_termination = f"ACK E {decode_message[2:]}"
        client_socket.sendto(ack_termination.encode(), (SERVER_IP, SERVER_PORT))
        print(f"Sent ACK for termination to client: {ack_termination}")
        
        ack_termination_confirm_message, server_address = client_socket.recvfrom(1024)
        decode_ack_termination_confirm_message = ack_termination_confirm_message.decode()
        print(f"Receive ACK termination confirmed from server: {decode_ack_termination_confirm_message}")

        
        break

    #regular request print
    print(f"Received request from server: {decode_message}")


    # Extract sequence number from the received message
    #_, seqno, _ = decode_message.split()
    
    # Generate timestamp for ACK message
    ACK_timestamp = get_timestamp()
    ack_message = f"ACK R {seqno:05d} {ACK_timestamp}"
    
    # Send ACK message back to the server
    client_socket.sendto(ack_message.encode(), (SERVER_IP, SERVER_PORT))
    print(f"Sent ACK to server: {ack_message}")

    # Receive ACK confirm message from the client
    ack_confirm_message, server_address = client_socket.recvfrom(1024)
    decode_ack_confirm_message = ack_confirm_message.decode()
    print(f"Receive ACK confirmation from server: {decode_ack_confirm_message}")
    
    seqno += 1


client_socket.close()

print("Client shutdown.")


